package ordkedja;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ExempelKod {
	
	public static void readData() throws IOException {

	BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream("files/ord14.txt")));
	ArrayList<String> words = new ArrayList<String>();

	while(true) {

		String word = r.readLine();

		if (word == null) {
			break;
		}
		assert word.length() == 5; // indatakoll, om man k�r med assertions p� words.add(word); }
		
	}

}
	// V = words.size();
	
	
	
	
	public static void testfall() throws IOException {
		BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream("files/testfall14.txt")));
		while (true) {
			String line = r.readLine();
			if (line == null) { 
				break;
				}
			assert line.length() == 11; // indatakoll, om man k�r med assertions p� 
			String start = line.substring(0, 5);
			String goal = line.substring(6, 11); // ... s�k v�g fr�n start till goal h�r
			
			}
		}
	

	
	public static void main(String[] args) throws IOException {
		readData();
		testfall();
		
	}
	}

